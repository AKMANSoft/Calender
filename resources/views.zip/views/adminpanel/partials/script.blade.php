<!-- Vendor js -->
<script src="{{asset('assets')}}/js/vendor.min.js"></script>

<!-- third party js -->
<script src="{{asset('assets')}}/libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="{{asset('assets')}}/libs/datatables.net-bs5/js/dataTables.bootstrap5.min.js"></script>
<script src="{{asset('assets')}}/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="{{asset('assets')}}/libs/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js"></script>
<script src="{{asset('assets')}}/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="{{asset('assets')}}/libs/datatables.net-buttons-bs5/js/buttons.bootstrap5.min.js"></script>
<script src="{{asset('assets')}}/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="{{asset('assets')}}/libs/datatables.net-buttons/js/buttons.flash.min.js"></script>
<script src="{{asset('assets')}}/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="{{asset('assets')}}/libs/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
<script src="{{asset('assets')}}/libs/datatables.net-select/js/dataTables.select.min.js"></script>
<script src="{{asset('assets')}}/libs/pdfmake/build/pdfmake.min.js"></script>
<script src="{{asset('assets')}}/libs/pdfmake/build/vfs_fonts.js"></script>
<!-- third party js ends -->

<!-- Datatables init -->
<script src="{{asset('assets')}}/js/pages/datatables.init.js"></script>

<!-- App js -->
<script src="{{asset('assets')}}/js/app.min.js"></script>
@yield('custom-script')
